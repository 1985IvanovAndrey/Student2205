CREATE FUNCTION integer_pl_date(integer, date)
  RETURNS date
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

