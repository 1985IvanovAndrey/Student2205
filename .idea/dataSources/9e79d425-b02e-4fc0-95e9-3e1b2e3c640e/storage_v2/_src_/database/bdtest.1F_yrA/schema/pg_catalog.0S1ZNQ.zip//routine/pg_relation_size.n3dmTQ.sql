CREATE FUNCTION pg_relation_size(regclass)
  RETURNS bigint
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.pg_relation_size($1, 'main')
$$;

